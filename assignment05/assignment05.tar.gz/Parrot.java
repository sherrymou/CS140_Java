package assignment05;
	
public class Parrot extends Animal{
	private String words;
	public Parrot(String name, String words){
		super(name);
		this.words = words;
		}

	public String speak(){
		return this.words;}
}
