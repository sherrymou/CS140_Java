package assignment05;

import java.util.ArrayList;

public class Counter {
    public static ArrayList<Integer> count(ArrayList<Animal> al) {
        // return an ArrayList<Integer> where the number of
        // instances of specific classes is at the
        // following indexes:
		ArrayList<Integer> result= new ArrayList<>();
		Integer total = 0;
		Integer bunny = 0;
		Integer bear = 0;
		Integer panda = 0;
		Integer parrot = 0;
		for (Animal a:al){
			if (a instanceof Animal){
				total ++;
				if (a instanceof Bunny){
					bunny ++;}else if (a instanceof Parrot){
					parrot ++;}else if (a instanceof Bear){
					if (a instanceof Panda){
					panda ++;}else{bear ++;}}
			}
        // 0 - the number of total Animals
        // 1 - the number of objects of type Bunny
        // 2 - the number of objects of type Bear (but not pandas)
        // 3 - the number of objects of type Panda
        // 4 - the number of objects of type Parrot
    	}
		result.add(total);
		result.add(bunny);
		result.add(bear);
		result.add(panda);
		result.add(parrot);
		return result;
	}
}
