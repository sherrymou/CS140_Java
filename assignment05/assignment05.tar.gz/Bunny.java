package assignment05;

public class Bunny extends Animal {
    public Bunny(String name) {
        super(name);
    }

	public String speak(){return "";}
}


