package assignment03;

public class Bunny {
    private String name;

    public Bunny(String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
