package exam01;

public class Box{
	private int value;

	public void setValue(int value){
		this.value=value;
	}
	
	public int getValue(){
		return this.value;	
	}
}
