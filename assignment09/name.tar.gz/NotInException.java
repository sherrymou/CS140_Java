package assignment09;

public class NotInException extends Exception {
	
}