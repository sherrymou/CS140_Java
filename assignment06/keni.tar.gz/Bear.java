package assignment06;

public class Bear extends Thing{
	public Bear(){
		super(30,10);
	}

}