package assignment06;

public class Bunny extends Thing{
	public Bunny(){
		super(20,3);
	}

}